# realtime-chat-local-session-storage

Для установки и настройки проекта:

- скачайте репозиторий или клонируйте его командой git clone https://github.com/robertd2000/realtime-chat-local-session-storage.git
- перейдите в директорию с проектом или установите необходимые зависимости командой npm install
- запустите приложение командой npm run dev

[Протестировать на GitHub Pages](https://robertd2000.github.io/realtime-chat-local-session-storage/)

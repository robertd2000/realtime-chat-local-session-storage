export const STORAGE_MESSAGES = 'messages'
export const STORAGE_USERS = 'user'
